-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Anamakine: localhost:3306
-- Üretim Zamanı: 18 Eki 2015, 20:57:54
-- Sunucu sürümü: 5.5.42
-- PHP Sürümü: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `testdb`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `left_node` int(11) NOT NULL,
  `right_node` int(11) NOT NULL,
  `cat_link` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `image` varchar(255) NOT NULL,
  `banner` varchar(255) NOT NULL,
  `queue` int(11) NOT NULL,
  `list_layout` int(11) NOT NULL,
  `meta_description` varchar(255) NOT NULL,
  `meta_keyword` varchar(200) NOT NULL,
  `meta_title` varchar(200) NOT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('12cf5bbb5cc6dee59ac2011f7f9c3d523b6ca2c4', '::1', 1444767926, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343736373636343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('1371254b77631aea8f7316b677e668b972ce61cb', '::1', 1444767222, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343736373032383b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('276d96eab60dbc58c7808c5143d42c762ed16c00', '::1', 1445024149, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434353032343134343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('3b826b6f448fa62ccfa4cab40e8a789ffdb3adb3', '::1', 1444558604, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343535383338313b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('3bcab74d6ad5a71c1c6810095acff8d103e48a40', '::1', 1444768846, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343736383834363b),
('470dbc24bfb395bab93360f1d81069d665f37666', '::1', 1444674407, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343637343135373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('5311f4dabd22195bb0aa9a0abb7a2a4d11c47d3e', '::1', 1444554769, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343535343530333b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('654d89d7c81da0fa3cc865870b5eee9dfc89f73f', '::1', 1444555967, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343535353737373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('6abcd9c1f8693038360bde4adca931f62b540a97', '::1', 1444766340, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343736363039373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('6b0dfac72ac86a1022c7e3ba14590771143f7eb8', '::1', 1444760607, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343736303531353b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('73ce831172bf9cbc8ef66ab8899862211d98fc2d', '::1', 1444557437, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343535373335333b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('752ecad3d025ab927c892c264503759015da0aa3', '::1', 1444672267, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343637323236373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('8ca795cdd2dcd4320f4b62f060711c3b09f3a3d8', '::1', 1445188128, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434353138383132363b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('a1c5c40570be9c992c0109633deafe41a279690f', '::1', 1445192619, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434353139323630393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('a3931eaac1e2e1257866f2f6189640b52e856960', '::1', 1444671914, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343637313839393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('acfc321c2e508c048c732723b2f7d91b3fc92f44', '::1', 1444758329, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343735383330373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('b46fc81f4ddb650cceef2a87d12b8ce4a45cac2e', '::1', 1444674051, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343637333834333b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('b53ad6c49dede6ebb89d70a4ebcebd1b314a525e', '::1', 1444673499, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343637333439323b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('b81e3b17b2927c81dc25f8be02c816d16e406837', '::1', 1444556872, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343535363537343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('eb56c8328a71d4ab08d8ee92d4ebf38e6735daf9', '::1', 1444765394, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343736353332393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('f1c39f872f0b310e5d7f9eb4b8e49e313dbbc867', '::1', 1444557207, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343535373033373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('f48b86c58d7074ffb5880b49eaa543dd772b225c', '::1', 1445193537, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434353139333533373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('f610a43bae743c38106f31b08e53c706e7ba2775', '::1', 1444672834, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343637323637323b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('f6e7925e6bc9a2222a3177835a10d7d5b62944e3', '::1', 1444673384, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434343637333131393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `news`
--

INSERT INTO `news` (`id`, `title`, `slug`, `text`) VALUES
(4, 'php ogreniyorum', 'php-ogreniyorum', 'beyler php ogreniyorum ve ilk makale kayıt islemlerimiz basladi.'),
(5, 'asp.net ogreniyorum', 'aspnet-ogreniyorum', 'asp.net ogreniyorum ve xxx islemleri ole bi basladimki hala devam ediyorum.'),
(6, 'html ogreniyorum', 'html-ogreniyorum', 'htmle basladik ulan ne guzel gidiyor derken nerden bilecektim sanal hammal olacagimi oldukmu sanal hammal hayatim iste o zaman kaydi gitti.');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `permissions`
--

INSERT INTO `permissions` (`id`, `name`) VALUES
(3, 'admin-login');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `site_settings`
--

CREATE TABLE `site_settings` (
  `id` int(11) NOT NULL,
  `settings_name` varchar(120) NOT NULL,
  `settings_key` text NOT NULL,
  `settings_value` text NOT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `themes`
--

CREATE TABLE `themes` (
  `id` int(11) NOT NULL,
  `themes_area_id` int(11) NOT NULL,
  `default_themes_id` tinyint(1) NOT NULL,
  `active_themes_id` tinyint(1) NOT NULL,
  `name` varchar(120) NOT NULL,
  `content` text NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `themes`
--

INSERT INTO `themes` (`id`, `themes_area_id`, `default_themes_id`, `active_themes_id`, `name`, `content`, `file_path`, `create_time`, `update_time`) VALUES
(17, 2, 1, 1, 'hazir tema footer', 'hazir tema footer icerik', 'themes/footer/footer17.php', '2015-10-04 14:38:48', '2015-10-08 18:17:04'),
(18, 5, 1, 1, 'hazir tema', 'hazir tema showcase views icerik guncelleme - varsayılan ,aktif', 'themes/showcase/views/showcase-views18.php', '2015-10-04 14:52:44', '2015-10-06 21:34:15'),
(19, 7, 1, 0, 'hazir tema blog frame', 'hazir tema blog frame icerik', 'themes/blog/frame/blog-frame19.php', '2015-10-04 15:01:26', '2015-10-04 16:01:26'),
(22, 1, 1, 0, 'maviweb1', 'varsayılan tema olarak seçtim guncelleme 00.31\r\naktif tema olarak seçtim guncelleme 00.31\r\n{logo}', 'themes/header/header22.php', '2015-10-06 20:28:52', '2015-10-12 18:22:37'),
(23, 4, 1, 0, 'hazir tema', 'showcase frame - guncelleme - varsayılan tema, aktif tema', 'themes/showcase/frame/showcase-frame23.php', '2015-10-06 20:33:22', '2015-10-06 21:35:27'),
(24, 4, 0, 1, 'maviweb1', 'tema aktif olarak seçtim', 'themes/showcase/frame/showcase-frame24.php', '2015-10-06 20:35:27', '2015-10-06 21:35:27'),
(25, 1, 0, 1, 'tema yapiliyor', '<div id="header">\r\n  <div class="logo">{logo}</div>\r\n  <div class="hmenu">\r\n   <ul class="hmenu_ul">\r\n    {kategoriler}\r\n   </ul>\r\n  </div>\r\n  </div>', 'themes/header/header25.php', '2015-10-12 17:11:32', '2015-10-12 18:20:51');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `themes_area`
--

CREATE TABLE `themes_area` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_extension` varchar(120) NOT NULL,
  `class_name` varchar(80) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `themes_area`
--

INSERT INTO `themes_area` (`id`, `parent_id`, `name`, `file_path`, `file_extension`, `class_name`, `create_time`, `update_time`) VALUES
(1, 0, 'header', 'themes/header/', 'header', 'header', '2015-09-22 21:00:00', '2015-10-08 19:41:35'),
(2, 0, 'footer', 'themes/footer/', 'footer', 'footer', '2015-09-22 21:00:00', '2015-10-08 19:41:39'),
(3, 0, 'showcase', 'themes/showcase/', 'showcase', 'showcase', '2015-09-22 21:00:00', '2015-10-08 19:41:47'),
(4, 3, 'showcase frame', 'themes/showcase/frame/', 'showcase-frame', 'showcase_frame', '2015-09-22 21:00:00', '2015-10-08 19:42:15'),
(5, 3, 'showcase views', 'themes/showcase/views/', 'showcase-views', 'showcase_views', '2015-09-22 21:00:00', '2015-10-08 19:42:10'),
(6, 0, 'blog', 'themes/blog/', 'blog', 'blog', '2015-09-22 21:00:00', '2015-10-08 19:42:18'),
(7, 6, 'blog frame', 'themes/blog/frame/', 'blog-frame', 'blog_frame', '2015-09-22 21:00:00', '2015-10-08 19:42:23'),
(8, 6, 'blog views', 'themes/blog/views/', 'blog-views', 'blog_views', '2015-09-22 21:00:00', '2015-10-08 19:42:29');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(120) NOT NULL,
  `name` varchar(120) NOT NULL,
  `surname` varchar(120) NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `name`, `surname`, `created_time`, `updated_time`) VALUES
(2, 'huseyindol', '4af6e55debe20f1aed19dcd8905312873dee6d06d33f973e2b958e43f476c0f1d709233a1eefef25f6382c1cda05a719d927171653f95bbef3409ae524dd7045K853qiCk53FP+wifJ+zlZZhw+jUBUP1lgXhML4WO9BY=', 'huseyindol@gmail.coms', 'huseyin', 'dol', '2015-09-09 00:00:00', '2015-10-06 22:41:04'),
(3, 'zehradol', 'bd8128748da0b91bf001d2601b2bec2b8744dab670884fc10af1782f88a7cc02d1fac9ff6f2d7029adbcc19b0ffd591e04a8a2e82b3c14cdb9fba9c26d1c70ceR7ND6JMqOJfc5lnz6jQ176QOP+begsUv8JzMgwf07mM=', 'zehradol@hotmail.com', 'zehra', 'dol', '2015-09-15 00:00:00', '2015-09-15 20:15:16'),
(4, 'yunusdol', 'ff4104efc909d83477c4fd709621852446aafe88534dd027fb37fc0814aef32dded28aae6c6e18963f4e30dff750b9e6bacdbc3c2b0a44d49593275f2f8617a4N0eawTrIDz6Q6jsAEijGp0A98vHasOXXerMjKihkXuE=', 'yunusdol@hotmail.com', 'yunus', 'dol', '0000-00-00 00:00:00', '2015-09-15 20:33:56'),
(5, 'nergizdol', 'bd7437119079aae2b5fc1dac618a6a74483e06a8d10b0457722bee6aacbe615b79d2d8565d1e0acdc3e93934ed1a33e6341994b01c9a0e674cd3075d6ac331b4y9aqbiTdYX1uNXq4CS9a8BlQ5NOvt71C0cEkmovfcu8=', 'nergizdol@gmail.com', 'nergiz', 'dol', '2015-09-15 22:40:33', '2015-09-15 20:40:33');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users_details`
--

CREATE TABLE `users_details` (
  `users_id` int(11) NOT NULL,
  `phone` char(15) NOT NULL,
  `phone2` char(15) NOT NULL,
  `gsm` char(15) NOT NULL,
  `seniority` varchar(80) NOT NULL,
  `tc_no` char(11) NOT NULL,
  `corporation` varchar(255) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `users_details`
--

INSERT INTO `users_details` (`users_id`, `phone`, `phone2`, `gsm`, `seniority`, `tc_no`, `corporation`, `address`) VALUES
(2, '2125983352', '1234567890', '5445582825', 'senior front-end developers', '1234567890', 'projesoft bilişim hizmetleri web tasarım ve programlama', 'fevzi çakmak mahallesi türkeli sokak no:30 d:4');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users_permissions`
--

CREATE TABLE `users_permissions` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `permissions_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `users_permissions`
--

INSERT INTO `users_permissions` (`id`, `users_id`, `permissions_id`) VALUES
(3, 2, 3);

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Tablo için indeksler `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slug` (`slug`);

--
-- Tablo için indeksler `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `themes_area_id` (`themes_area_id`);

--
-- Tablo için indeksler `themes_area`
--
ALTER TABLE `themes_area`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Tablo için indeksler `users_details`
--
ALTER TABLE `users_details`
  ADD UNIQUE KEY `users_id` (`users_id`);

--
-- Tablo için indeksler `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `permissions_id` (`permissions_id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- Tablo için AUTO_INCREMENT değeri `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Tablo için AUTO_INCREMENT değeri `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- Tablo için AUTO_INCREMENT değeri `themes`
--
ALTER TABLE `themes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- Tablo için AUTO_INCREMENT değeri `themes_area`
--
ALTER TABLE `themes_area`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- Tablo için AUTO_INCREMENT değeri `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- Tablo için AUTO_INCREMENT değeri `users_permissions`
--
ALTER TABLE `users_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `themes`
--
ALTER TABLE `themes`
  ADD CONSTRAINT `themes-area` FOREIGN KEY (`themes_area_id`) REFERENCES `themes_area` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Tablo kısıtlamaları `users_details`
--
ALTER TABLE `users_details`
  ADD CONSTRAINT `details-users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Tablo kısıtlamaları `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD CONSTRAINT `us_pe-to-permissions` FOREIGN KEY (`permissions_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `us_pe-to-users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

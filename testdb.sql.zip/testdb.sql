-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 02 Ara 2015, 14:05:22
-- Sunucu sürümü: 5.6.17
-- PHP Sürümü: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `testdb`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `cat_link` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  `queue` int(11) NOT NULL,
  `list_layout` int(11) NOT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(200) DEFAULT NULL,
  `meta_title` varchar(200) DEFAULT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Tablo döküm verisi `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `status`, `cat_link`, `name`, `description`, `image`, `banner`, `queue`, `list_layout`, `meta_description`, `meta_keyword`, `meta_title`, `created_time`, `updated_time`) VALUES
(1, 0, 1, 'cat_link', 'Electronics', 'Electronics desc', '', '', 1, 4, 'Electronics meta_description', 'Electronics meta_keyword', 'Electronics meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(2, 1, 1, 'cat_link', 'Televisions', 'Televisions desc', '', '', 1, 4, 'Televisions meta_description', 'Televisions meta_keyword', 'Televisions meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(3, 1, 1, 'cat_link', 'Portable Electronics', 'Portable Electronics desc', '', '', 2, 4, 'Portable Electronics meta_description', 'Portable Electronics meta_keyword', 'Portable Electronics meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(4, 3, 1, 'cat_link', 'Mp3 Players', 'Mp3 Players desc', '', '', 1, 4, 'Mp3 Players meta_description', 'Mp3 Players meta_keyword', 'Mp3 Players meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(5, 3, 1, 'cat_link', 'Cd Players', 'Cd Players desc', '', '', 2, 4, 'Cd Players meta_description', 'Cd Players meta_keyword', 'Cd Players meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(6, 3, 1, 'cat_link', '2 Way Radios', '2 Way Radios desc', '', '', 3, 4, '2 Way Radios meta_description', '2 Way Radios meta_keyword', '2 Way Radios meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(7, 4, 1, 'cat_link', 'Flash', 'Flash desc', '', '', 1, 4, 'Flash meta_description', 'Flash meta_keyword', 'Flash meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(8, 2, 1, 'cat_link', 'Tube', 'Tube desc', '', '', 2, 4, 'Tube meta_description', 'Tube meta_keyword', 'Tube meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(9, 2, 1, 'cat_link', 'Lcd', 'Lcd desc', '', '', 2, 4, 'Lcd meta_description', 'Lcd meta_keyword', 'Lcd meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(10, 2, 1, 'cat_link', 'Plasma', 'Plasma desc', '', '', 3, 4, 'Plasma meta_description', 'Plasma meta_keyword', 'Plasma meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(11, 10, 1, 'cat_link', 'deneme11', 'deneme11 description', '', '', 1, 4, 'deneme11 meta_description', 'deneme11 meta_keyword', 'deneme11 meta_title', '2015-10-28 21:00:00', '2015-10-29 20:04:58'),
(29, 0, 1, '', 'Kategori 1', 'Kategori 1 açıklama', '', '', 0, 0, 'Kategori 1 meta description', 'Kategori 1 meta keyword', 'Kategori 1 meta title', '2015-11-17 21:11:04', '2015-12-01 08:03:46'),
(30, 0, 1, '', 'kategori 2', 'kategori 2 açıklama', '', '', 0, 0, 'kategori 2 description', 'kategori 2 keyword', 'kategori 2 title', '2015-11-18 21:38:36', '2015-12-01 08:03:41');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('026f59144dadbba1b76f3dad2cd10b60daa0d4a0', '::1', 1448193262, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383139333030323b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('0566aa1c27f8014074b415db6275a7362d0a2fa8', '::1', 1448191506, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383139313435333b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('0e0fa4a190c6b94344d33cf19f4f2acbb150a5cc', '::1', 1447890574, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373839303238363b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('0fdb601b383b79d60d2d45b7598d436391dd2b76', '::1', 1448147539, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383134373533323b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('1c78ef469310a0527e506be77ed927dde1848cdb', '::1', 1447892031, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373839323031303b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('1e35b0df965fd988c92f432ebf0ed461d41eb3ff', '::1', 1448217857, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383231373732313b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('1f8a52e14a803e9b9a56e6b4411892b921b1f581', '::1', 1447889022, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373838383739343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('1feed16900e7b1daa7761556e93c5c86e42b457d', '::1', 1448143676, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383134333637303b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('2004d03edbd695686fdd30800ec3f3adf355c7c4', '::1', 1448146199, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383134363037363b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('2157a6d02cd0013017695ec8813b13185906a992', '::1', 1448444649, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383434343634393b),
('2ee99958e85df581aeb9d219e167b7da4b0108de', '::1', 1448195286, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383139353238363b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('33da158fd2e6294882891949eb6c5616b65448b4', '::1', 1448196526, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383139363232393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('3d331a9c1e7c642e459aa87c19e878893fd558d3', '::1', 1448193910, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383139333639363b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('3eb001ba9682acb06b8dc162bbbcf735127446fa', '::1', 1448352500, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383335323439353b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('3f286e291498136a899e83bc51a8623802843bbb', '::1', 1448196693, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383139363630353b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('43d87906d6306f8c2d1d18a17c35d48da16ad435', '::1', 1448195943, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383139353735393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('52333443cb9feabfbd1050385eb05d03b0ca1a84', '::1', 1448957980, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383935373639373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('5914156faf9e98addd6d21baa9c4cc31d8c12e2d', '::1', 1448194785, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383139343534333b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('63668975440ad8a7929ed7e9923ff2f32cbee3c6', '::1', 1448523837, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383532333832303b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('661f3e55f8c272b73639b5472fe9d9aa256c180e', '::1', 1448552575, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383535323536343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('68790bc14f537c5f39ed21868a331c631fe2e444', '::1', 1447883970, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373838333936343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('69f57b1d101b81346f761a9393f3c0286990a722', '::1', 1448198239, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383139383233373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('71647913945916f6194079e3549554e295ded60e', '::1', 1448958094, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383935383032393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('750258f3c505fe312edfdf53d0f1a059b572f0f3', '::1', 1447889695, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373838393532393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('79dd1018543101571014dc068815805407a09174', '::1', 1447888377, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373838383039393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('7b06389e6fb16cf9cf3731100c2358d8350b8e8f', '::1', 1448188076, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383138373936353b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('7e81ecd5efe3158fd5f5384c96e5b9cdc0f28253', '::1', 1448349149, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383334393134313b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('8060061544ec426da19217c0c06f1ad9381c631f', '::1', 1448956690, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383935363633343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('8c7c6a5defd114fc9388c5076bcbaba7fd8d7cd6', '::1', 1448310009, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383331303030393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('9122fb62b8786a8e97aa73afaf075f210c5b9e41', '::1', 1447887605, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373838373333363b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('b13d4a2d38350ee9b78c8a171870499d8fb6bb0f', '::1', 1447886857, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373838363632333b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('b2f3e8f2c09c674300790671699fb3737705f576', '::1', 1447886528, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373838363237323b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('b506853e1f7cefe8e739f7ef91b42497bb7b85f6', '::1', 1447890063, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373838393839323b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('c0765885dd109b99020aaafd25fae59bbb551fff', '::1', 1447890883, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373839303836373b757365726e616d657c733a383a227a65687261646f6c223b69735f6c6f676765645f696e7c623a313b),
('c688e306bb36bec534f3c64e3f7e305e9615b288', '::1', 1448187318, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383138373037363b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('c6b37122ecc5aca75fbae3722ad4b11d54ff234f', '::1', 1448957303, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383935373030343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('d8bc1ed694216cc25944605e30cc5278f278c0d5', '::1', 1448307818, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383330373831343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('d8e5b293c00d7035a4864a1e61f596b89a8ab45f', '::1', 1448436853, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383433363832353b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('df8ca0f4499c0e610a7cf69e0992d85817da3828', '::1', 1448195111, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383139343933383b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('e14a1e49a1deffff3eba2bf64c1173677cd02c68', '::1', 1448352104, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383335323039373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('e41ca53f923969e77e86843bf465253ac6e1070b', '::1', 1447887235, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434373838363935393b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('e8b738ef070c3a5a652d8a132ba5330be1bfd307', '::1', 1448437884, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383433373639353b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('e9337f37d54324fbc9fb526620662a2ad60857e2', '::1', 1448219905, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383231393930303b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('eeb8f8402035f2d832410874099e92586514b381', '::1', 1448957683, 0x5f5f63695f6c6173745f726567656e65726174657c693a313434383935373339363b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `slug` (`slug`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Tablo döküm verisi `news`
--

INSERT INTO `news` (`id`, `title`, `slug`, `text`) VALUES
(4, 'php ogreniyorum', 'php-ogreniyorum', 'beyler php ogreniyorum ve ilk makale kayıt islemlerimiz basladi.'),
(5, 'asp.net ogreniyorum', 'aspnet-ogreniyorum', 'asp.net ogreniyorum ve xxx islemleri ole bi basladimki hala devam ediyorum.'),
(6, 'html ogreniyorum', 'html-ogreniyorum', 'htmle basladik ulan ne guzel gidiyor derken nerden bilecektim sanal hammal olacagimi oldukmu sanal hammal hayatim iste o zaman kaydi gitti.');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(140) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Tablo döküm verisi `permissions`
--

INSERT INTO `permissions` (`id`, `name`) VALUES
(3, 'administrator');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `site_settings`
--

CREATE TABLE IF NOT EXISTS `site_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `settings_name` varchar(120) NOT NULL,
  `settings_key` text NOT NULL,
  `settings_value` text NOT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Tablo döküm verisi `site_settings`
--

INSERT INTO `site_settings` (`id`, `settings_name`, `settings_key`, `settings_value`, `created_time`, `updated_time`) VALUES
(1, 'enable_responsive', 'enable_responsive', '', '2015-11-21 22:00:00', '2015-12-01 08:20:29'),
(2, 'restrict_roaming', 'restrict_roaming', 'enable', '2015-11-21 22:00:00', '2015-12-01 08:20:30'),
(3, 'site_logo', 'site_logo', 'site_logo', '2015-11-21 22:00:00', '2015-12-01 08:20:30'),
(4, 'watermark', 'watermark', 'watermark', '2015-11-21 22:00:00', '2015-12-01 08:20:30'),
(5, 'home_page_sidebar', 'home_page_sidebar', 'enable_sidebar', '2015-11-21 22:00:00', '2015-12-01 08:20:30'),
(6, 'home_page_passive_footer', 'home_page_passive_footer', '', '2015-11-21 22:00:00', '2015-11-22 18:40:05'),
(7, 'category_page_sidebar', 'category_page_sidebar', 'enable_sidebar', '2015-11-21 22:00:00', '2015-12-01 08:20:30'),
(8, 'category_page_passive_footer', 'category_page_passive_footer', '', '2015-11-21 22:00:00', '2015-11-22 18:40:15'),
(9, 'search_page_sidebar', 'search_page_sidebar', 'enable_sidebar', '2015-11-21 22:00:00', '2015-12-01 08:20:30'),
(10, 'search_page_passive_footer', 'search_page_passive_footer', '', '2015-11-21 22:00:00', '2015-11-22 18:40:35'),
(11, 'brand_page_sidebar', 'brand_page_sidebar', 'enable_sidebar', '2015-11-21 22:00:00', '2015-12-01 08:20:30'),
(12, 'brand_page_passive_footer', 'brand_page_passive_footer', '', '2015-11-21 22:00:00', '2015-11-22 18:40:46'),
(13, 'product_page_sidebar', 'product_page_sidebar', 'enable_sidebar', '2015-11-21 22:00:00', '2015-12-01 08:20:30'),
(14, 'product_page_passive_footer', 'product_page_passive_footer', '', '2015-11-21 22:00:00', '2015-11-22 18:40:56'),
(15, 'blog_page_sidebar', 'blog_page_sidebar', 'enable_sidebar', '2015-11-21 22:00:00', '2015-12-01 08:20:30'),
(16, 'blog_page_passive_footer', 'blog_page_passive_footer', '', '2015-11-21 22:00:00', '2015-11-22 18:41:06'),
(17, 'home_restrict_roaming', 'home_restrict_roaming', '', NULL, '2015-12-01 08:16:41'),
(18, 'listing_restrict_roaming', 'listing_restrict_roaming', 'enable', NULL, '2015-12-01 08:20:30'),
(19, 'details_restrict_roaming', 'details_restrict_roaming', 'enable', NULL, '2015-12-01 08:20:30'),
(20, 'blog_restrict_roaming', 'blog_restrict_roaming', 'enable', NULL, '2015-12-01 08:20:30');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `themes`
--

CREATE TABLE IF NOT EXISTS `themes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `themes_area_id` int(11) NOT NULL,
  `default_themes_id` tinyint(1) NOT NULL,
  `active_themes_id` tinyint(1) NOT NULL,
  `name` varchar(120) NOT NULL,
  `content` text NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `themes_area_id` (`themes_area_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Tablo döküm verisi `themes`
--

INSERT INTO `themes` (`id`, `themes_area_id`, `default_themes_id`, `active_themes_id`, `name`, `content`, `file_path`, `create_time`, `update_time`) VALUES
(17, 2, 1, 1, 'hazir tema footer', 'hazir tema footer icerik', 'themes/footer/footer17.php', '2015-10-04 14:38:48', '2015-10-08 18:17:04'),
(18, 5, 1, 1, 'hazir tema', 'hazir tema showcase views icerik guncelleme - varsayılan ,aktif', 'themes/showcase/views/showcase-views18.php', '2015-10-04 14:52:44', '2015-10-06 21:34:15'),
(19, 7, 1, 0, 'hazir tema blog frame', 'hazir tema blog frame icerik', 'themes/blog/frame/blog-frame19.php', '2015-10-04 15:01:26', '2015-10-04 16:01:26'),
(22, 1, 1, 0, 'maviweb1', 'varsayılan tema olarak seçtim guncelleme 00.31\r\naktif tema olarak seçtim guncelleme 00.31\r\n{logo}', 'themes/header/header22.php', '2015-10-06 20:28:52', '2015-10-12 18:22:37'),
(23, 4, 1, 0, 'hazir tema', 'showcase frame - guncelleme - varsayılan tema, aktif tema', 'themes/showcase/frame/showcase-frame23.php', '2015-10-06 20:33:22', '2015-10-06 21:35:27'),
(24, 4, 0, 1, 'maviweb1', 'tema aktif olarak seçtim', 'themes/showcase/frame/showcase-frame24.php', '2015-10-06 20:35:27', '2015-10-06 21:35:27'),
(25, 1, 0, 1, 'tema yapiliyor', '<div id="header">\r\n  <div class="logo">{logo}</div>\r\n  <div class="hmenu">\r\n   <ul class="hmenu_ul">\r\n    {kategoriler}\r\n   </ul>\r\n  </div>\r\n  </div>', 'themes/header/header25.php', '2015-10-12 17:11:32', '2015-10-12 18:20:51');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `themes_area`
--

CREATE TABLE IF NOT EXISTS `themes_area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_extension` varchar(120) NOT NULL,
  `class_name` varchar(80) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Tablo döküm verisi `themes_area`
--

INSERT INTO `themes_area` (`id`, `parent_id`, `name`, `file_path`, `file_extension`, `class_name`, `create_time`, `update_time`) VALUES
(1, 0, 'header', 'themes/header/', 'header', 'header', '2015-09-22 21:00:00', '2015-10-08 19:41:35'),
(2, 0, 'footer', 'themes/footer/', 'footer', 'footer', '2015-09-22 21:00:00', '2015-10-08 19:41:39'),
(3, 0, 'showcase', 'themes/showcase/', 'showcase', 'showcase', '2015-09-22 21:00:00', '2015-10-08 19:41:47'),
(4, 3, 'showcase frame', 'themes/showcase/frame/', 'showcase-frame', 'showcase_frame', '2015-09-22 21:00:00', '2015-10-08 19:42:15'),
(5, 3, 'showcase views', 'themes/showcase/views/', 'showcase-views', 'showcase_views', '2015-09-22 21:00:00', '2015-10-08 19:42:10'),
(6, 0, 'blog', 'themes/blog/', 'blog', 'blog', '2015-09-22 21:00:00', '2015-10-08 19:42:18'),
(7, 6, 'blog frame', 'themes/blog/frame/', 'blog-frame', 'blog_frame', '2015-09-22 21:00:00', '2015-10-08 19:42:23'),
(8, 6, 'blog views', 'themes/blog/views/', 'blog-views', 'blog_views', '2015-09-22 21:00:00', '2015-10-08 19:42:29');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(40) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(120) NOT NULL,
  `name` varchar(120) NOT NULL,
  `surname` varchar(120) NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Tablo döküm verisi `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `name`, `surname`, `created_time`, `updated_time`) VALUES
(2, 'huseyindol', '4af6e55debe20f1aed19dcd8905312873dee6d06d33f973e2b958e43f476c0f1d709233a1eefef25f6382c1cda05a719d927171653f95bbef3409ae524dd7045K853qiCk53FP+wifJ+zlZZhw+jUBUP1lgXhML4WO9BY=', 'huseyindol@gmail.coms', 'huseyin', 'dol', '2015-09-09 00:00:00', '2015-10-06 22:41:04'),
(3, 'zehradol', 'bd8128748da0b91bf001d2601b2bec2b8744dab670884fc10af1782f88a7cc02d1fac9ff6f2d7029adbcc19b0ffd591e04a8a2e82b3c14cdb9fba9c26d1c70ceR7ND6JMqOJfc5lnz6jQ176QOP+begsUv8JzMgwf07mM=', 'zehradol@hotmail.com', 'zehra', 'dol', '2015-09-15 00:00:00', '2015-09-15 20:15:16'),
(4, 'yunusdol', 'ff4104efc909d83477c4fd709621852446aafe88534dd027fb37fc0814aef32dded28aae6c6e18963f4e30dff750b9e6bacdbc3c2b0a44d49593275f2f8617a4N0eawTrIDz6Q6jsAEijGp0A98vHasOXXerMjKihkXuE=', 'yunusdol@hotmail.com', 'yunus', 'dol', '0000-00-00 00:00:00', '2015-09-15 20:33:56'),
(5, 'nergizdol', 'bd7437119079aae2b5fc1dac618a6a74483e06a8d10b0457722bee6aacbe615b79d2d8565d1e0acdc3e93934ed1a33e6341994b01c9a0e674cd3075d6ac331b4y9aqbiTdYX1uNXq4CS9a8BlQ5NOvt71C0cEkmovfcu8=', 'nergizdol@gmail.com', 'nergiz', 'dol', '2015-09-15 22:40:33', '2015-09-15 20:40:33');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users_details`
--

CREATE TABLE IF NOT EXISTS `users_details` (
  `users_id` int(11) NOT NULL,
  `phone` char(15) NOT NULL,
  `phone2` char(15) NOT NULL,
  `gsm` char(15) NOT NULL,
  `seniority` varchar(80) NOT NULL,
  `tc_no` char(11) NOT NULL,
  `corporation` varchar(255) NOT NULL,
  `address` text NOT NULL,
  UNIQUE KEY `users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Tablo döküm verisi `users_details`
--

INSERT INTO `users_details` (`users_id`, `phone`, `phone2`, `gsm`, `seniority`, `tc_no`, `corporation`, `address`) VALUES
(2, '2125983352', '1234567890', '5445582825', 'senior front-end developers', '1234567890', 'projesoft bilişim hizmetleri web tasarım ve programlama', 'fevzi çakmak mahallesi türkeli sokak no:30 d:4');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `users_permissions`
--

CREATE TABLE IF NOT EXISTS `users_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `users_id` int(11) NOT NULL,
  `permissions_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `permissions_id` (`permissions_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Tablo döküm verisi `users_permissions`
--

INSERT INTO `users_permissions` (`id`, `users_id`, `permissions_id`) VALUES
(3, 2, 3);

--
-- Dökümü yapılmış tablolar için kısıtlamalar
--

--
-- Tablo kısıtlamaları `themes`
--
ALTER TABLE `themes`
  ADD CONSTRAINT `themes-area` FOREIGN KEY (`themes_area_id`) REFERENCES `themes_area` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Tablo kısıtlamaları `users_details`
--
ALTER TABLE `users_details`
  ADD CONSTRAINT `details-users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Tablo kısıtlamaları `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD CONSTRAINT `us_pe-to-permissions` FOREIGN KEY (`permissions_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `us_pe-to-users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

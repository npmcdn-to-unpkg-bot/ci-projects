-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:3306
-- Generation Time: Feb 25, 2016 at 08:25 PM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `banner_type` varchar(80) NOT NULL,
  `target` varchar(80) NOT NULL,
  `image` varchar(150) NOT NULL,
  `link` varchar(150) DEFAULT NULL,
  `alt_text` varchar(200) DEFAULT NULL,
  `queue` int(11) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `banner_type`, `target`, `image`, `link`, `alt_text`, `queue`, `create_time`, `update_time`) VALUES
(6, 'slide', 'home', 'assets/uploads/system/images/home_6_Wn6sgfKY3ZbRGr-manzara02.jpg', 'manzara-blog2.html', 'manzara 02', 2, '2016-01-30 21:53:09', '2016-02-01 20:18:22'),
(7, 'slide', 'home', 'assets/uploads/system/images/home_7_AIn6XJT6oxmp6r-manzara03.jpg', 'manzara-blog3.html', 'manzara 03', 3, '2016-01-30 21:53:30', '2016-01-30 22:53:54'),
(8, 'slide', 'home', 'assets/uploads/system/images/home_8_WsKGuhemTwRlna-manzara01.jpg', 'manzara-blog1.html', 'manzara 01', 1, '2016-01-30 21:55:01', '2016-01-30 22:55:04'),
(12, 'slide', 'cat_1', 'assets/uploads/system/images/cat_1_12_Jx9ZtP4Pfk4Z2B-wallhaven-248171.jpg', '', '', NULL, '2016-02-02 09:02:28', '2016-02-02 10:02:28'),
(14, 'banner', 'home', 'assets/uploads/system/images/home_14_m8UtGazCTkIOKj-dag01.jpg', '', '', NULL, '2016-02-05 20:20:09', '2016-02-05 21:20:09'),
(15, 'banner', 'home', 'assets/uploads/system/images/home_15_HVHL72YfCuhItJ-dag02.jpg', '', '', NULL, '2016-02-05 21:25:29', '2016-02-05 22:25:29'),
(16, 'banner', 'home', 'assets/uploads/system/images/home_16_r63FRdEpu4zC0q-dag03.png', '', '', NULL, '2016-02-05 21:25:38', '2016-02-05 22:25:38');

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `pages_type` varchar(80) NOT NULL,
  `pages_link` varchar(200) NOT NULL,
  `perma_link` varchar(200) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `content` text,
  `list_title` varchar(200) DEFAULT NULL,
  `list_content` text,
  `list_image` varchar(200) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(200) DEFAULT NULL,
  `meta_title` varchar(200) DEFAULT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`id`, `pages_type`, `pages_link`, `perma_link`, `title`, `content`, `list_title`, `list_content`, `list_image`, `meta_description`, `meta_keyword`, `meta_title`, `created_time`, `updated_time`) VALUES
(1, 'pages_type', 'pages_link', 'perma_link', 'blog başlık 1', '<p>dfdf&nbsp;asdy.&ccedil;&ouml;kuişj&ouml;ghn &nbsp;ğpk kpğkpğmşdlm lkm klnlasndasofn lksnfpjkfp&nbsp;</p>\r\n', 'blog başlık 1', '<p>blog içerik 1 bu kısımda blog içerik gelmektedir.<br />\r\nblog içerik 1 bu kısımda blog içerik gelmektedir.</p>\r\n', 'assets/uploads/system/images/list_image_oUXVhtDtMWIMnq-CLGo0ijWIAEBnY9.jpg', 'blog 1 meta description', 'blog 1 meta keyword', 'blog 1 meta title', '2015-12-11 23:13:49', '2016-01-25 09:42:52'),
(10, 'pages_type', 'pages_link', 'perma_link', 'blog başlık 10', '<p>blog i&ccedil;erik 10</p>\r\n', 'blog 10 list başlık', '<p>blog 10 list içerik kısmı bu alana list içerik gelmektedir.<br />\r\nblog 10 list içerik kısmı bu alana list içerik gelmektedir.</p>\r\n', 'assets/uploads/system/images/list_image_L1gilQRdZq0G1d-wallhaven-229100.jpg', 'blog içerik 10 meta description', 'blog içerik 10 meta keyword', 'blog içerik 10 meta title', '2015-12-12 09:15:36', '2016-01-25 09:43:54'),
(11, 'pages_type', 'pages_link', 'perma_link', 'tyu başlık', '<p>tyu i&ccedil;erik</p>\r\n', 'tyu list başlık', '<p>tyu list içerik</p>\r\n', 'assets/uploads/system/images/list_image_QbnQf7SfNInYBc-list_image_cz9kD0vvF26OfM-dag01.jpg', 'tyu meta description', 'tyu meta keyword', 'tyu meta title', '2016-01-25 07:26:56', '2016-01-25 09:19:23');

-- --------------------------------------------------------

--
-- Table structure for table `blog_to_showcase`
--

CREATE TABLE `blog_to_showcase` (
  `id` int(11) NOT NULL,
  `blog_id` int(11) NOT NULL,
  `showcase_id` int(11) NOT NULL,
  `themes_area_id` int(11) NOT NULL,
  `themes_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog_to_showcase`
--

INSERT INTO `blog_to_showcase` (`id`, `blog_id`, `showcase_id`, `themes_area_id`, `themes_id`) VALUES
(42, 1, 2, 8, 27),
(43, 10, 2, 8, 27),
(44, 11, 3, 8, 0);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `cat_link` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  `queue` int(11) NOT NULL,
  `list_layout` int(11) NOT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(200) DEFAULT NULL,
  `meta_title` varchar(200) DEFAULT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `status`, `cat_link`, `name`, `description`, `image`, `banner`, `queue`, `list_layout`, `meta_description`, `meta_keyword`, `meta_title`, `created_time`, `updated_time`) VALUES
(1, 0, 1, 'cat_link', 'Electronics', 'Electronics desc', '', '', 1, 4, 'Electronics meta_description', 'Electronics meta_keyword', 'Electronics meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(2, 1, 1, 'cat_link', 'Televisions', 'Televisions desc', '', '', 1, 4, 'Televisions meta_description', 'Televisions meta_keyword', 'Televisions meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(3, 1, 1, 'cat_link', 'Portable Electronics', 'Portable Electronics desc', '', '', 2, 4, 'Portable Electronics meta_description', 'Portable Electronics meta_keyword', 'Portable Electronics meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(4, 3, 1, 'cat_link', 'Mp3 Players', 'Mp3 Players desc', '', '', 1, 4, 'Mp3 Players meta_description', 'Mp3 Players meta_keyword', 'Mp3 Players meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(5, 3, 1, 'cat_link', 'Cd Players', 'Cd Players desc', '', '', 2, 4, 'Cd Players meta_description', 'Cd Players meta_keyword', 'Cd Players meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(6, 3, 1, 'cat_link', '2 Way Radios', '2 Way Radios desc', '', '', 3, 4, '2 Way Radios meta_description', '2 Way Radios meta_keyword', '2 Way Radios meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(7, 4, 1, 'cat_link', 'Flash', 'Flash desc', '', '', 1, 4, 'Flash meta_description', 'Flash meta_keyword', 'Flash meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(8, 2, 1, 'cat_link', 'Tube', 'Tube desc', '', '', 2, 4, 'Tube meta_description', 'Tube meta_keyword', 'Tube meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(9, 2, 1, 'cat_link', 'Lcd', 'Lcd desc', '', '', 2, 4, 'Lcd meta_description', 'Lcd meta_keyword', 'Lcd meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(10, 2, 1, 'cat_link', 'Plasma', 'Plasma desc', '', '', 3, 4, 'Plasma meta_description', 'Plasma meta_keyword', 'Plasma meta_title', '2015-10-22 21:00:00', '2015-10-23 20:16:49'),
(11, 10, 1, 'cat_link', 'deneme11', 'deneme11 description', '', '', 1, 4, 'deneme11 meta_description', 'deneme11 meta_keyword', 'deneme11 meta_title', '2015-10-28 21:00:00', '2015-10-29 20:04:58'),
(29, 0, 1, '', 'Kategori 1', 'Kategori 1 açıklama', 'assets/uploads/system/images/catid_29_5mE2uspXTllktR-bban01.png', 'assets/uploads/system/images/catid_29_rCAlPPGHATXpgc-bban01.png', 0, 0, 'Kategori 1 meta description', 'Kategori 1 meta keyword', 'Kategori 1 meta title', '2015-11-17 21:11:04', '2015-11-30 19:52:29'),
(30, 0, 1, '', 'kategori 2', 'kategori 2 açıklama', '', '', 0, 0, 'kategori 2 description', 'kategori 2 keyword', 'kategori 2 title', '2015-11-18 21:38:36', '2015-11-30 20:57:54');

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE `ci_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('1e3c2886d6c25e419e6762bfa1a70521ed518758', '::1', 1455916169, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435353931363136343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b66726f6e74656e645f6c6f67696e5f617474656d70747c693a363b),
('6fe24c0f7ea5142db1a4ebbcf866320ed296e9f8', '::1', 1455920011, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435353931393936373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('9894255f83c3c8b8db971a37fe7922bd5a91db2f', '::1', 1455915711, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435353931353636373b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b66726f6e74656e645f6c6f67696e5f617474656d70747c693a343b),
('a180bc492d5dd2f91b72f3e5f6e68214b48cc721', '::1', 1455917773, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435353931373737303b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b66726f6e74656e645f6c6f67696e5f617474656d70747c693a373b),
('a40b20fd654c102971ffcfad9734013e0077891f', '::1', 1456073588, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435363037333538363b),
('aa9e2101f9d88b4af84d9ec078412e5cbb10a8dd', '::1', 1455920872, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435353932303837323b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('abed06be069aa7e1db845eac9be07fa25ea86399', '::1', 1456003168, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435363030333135343b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b66726f6e74656e645f757365726e616d657c733a31303a226875736579696e646f6c223b66726f6e74656e645f69735f6c6f676765645f696e7c623a313b66726f6e74656e645f76656e646f727c623a313b66726f6e74656e645f637573746f6d65727c623a313b),
('c58c11eb4e278a622460588a30227a22dbc22f1c', '::1', 1455915663, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435353931353336363b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('e0f35877ee66fe46e334613d3cf3d75fd746dd69', '::1', 1455980579, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435353938303536323b),
('e94f65a8c4cb5e04861816f24a929144637f8938', '::1', 1456428247, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435363432383232313b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b),
('eac92406161837293f290adf509f181e3f46ce0c', '::1', 1455915356, 0x5f5f63695f6c6173745f726567656e65726174657c693a313435353931353036333b757365726e616d657c733a31303a226875736579696e646f6c223b69735f6c6f676765645f696e7c623a313b66726f6e74656e645f757365726e616d657c733a31303a226875736579696e646f6c223b66726f6e74656e645f69735f6c6f676765645f696e7c623a313b66726f6e74656e645f76656e646f727c623a313b66726f6e74656e645f637573746f6d65727c623a313b);

-- --------------------------------------------------------

--
-- Table structure for table `custom_code`
--

CREATE TABLE `custom_code` (
  `id` int(11) NOT NULL,
  `custom_code_name` varchar(120) NOT NULL,
  `custom_code_key` text NOT NULL,
  `custom_code_value` text NOT NULL,
  `file_path` varchar(120) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `custom_code`
--

INSERT INTO `custom_code` (`id`, `custom_code_name`, `custom_code_key`, `custom_code_value`, `file_path`, `create_time`, `update_time`) VALUES
(1, 'themes_head_code', 'themes_head_code', '<meta charset="UTF-8">\r\n<title>frontend - home // themes-folder-x.php ile gelmekte.</title>\r\n<!-- stylesheet.css -->\r\n<link rel="stylesheet" href="assets/uploads/css/bootstrap-theme.min.css" />\r\n<link rel="stylesheet" href="assets/uploads/css/bootstrap.min.css" />\r\n<link rel="stylesheet" href="assets/uploads/css/swiper.min.css" />\r\n<link rel="stylesheet" href="assets/uploads/css/style.css" />\r\n<!-- script.js -->\r\n<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>\r\n<script src="assets/uploads/js/bootstrap.min.js"></script>\r\n<script src="assets/uploads/js/swiper.min.js"></script>', 'themes/head/head.php', '2015-12-04 22:00:00', '2016-02-09 21:55:38'),
(3, 'themes_foot_code', 'themes_foot_code', '<!-- script.js -->\r\n<script src="assets/uploads/js/site_custom.js"></script>\r\n<script>\r\n    $(document).ready(function(){\r\n        console.log(''themes-folder-x.php ile geliyor. site bitimi calisiyor..'');\r\n    });\r\n</script>', 'themes/foot/foot.php', '2015-12-04 22:00:00', '2016-02-05 21:46:38'),
(4, 'themes_slider_code', 'slider', '<div class="site_slider">\r\n	<ul>\r\n	{slider}\r\n		<li><a href="<?php echo $slider_value->link ?>" title="<?php echo $slider_value->alt_text ?>"><img src="<?php echo $slider_value->image ?>" alt="<?php echo $slider_value->alt_text ?>" height="500"/></a></li>\r\n	{/slider}\r\n	</ul>\r\n</div>	', 'themes/slider/slider.php', '2016-02-04 22:00:00', '2016-02-05 19:28:11'),
(5, 'themes_banner_code', 'banner', '<div class="site_banner">\r\n	<ul>\r\n	<?php foreach ($banner as $banner_key => $banner_value): ?>\r\n		<li><a href="<?php echo $banner_value->link ?>" title="<?php echo $banner_value->alt_text ?>"><img src="<?php echo $banner_value->image ?>" alt="<?php echo $banner_value->alt_text ?>" /></a></li>\r\n	<?php endforeach ?>\r\n	</ul>\r\n</div>', 'themes/banner/banner.php', '2016-02-04 22:00:00', '2016-02-05 19:24:05');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `slug` varchar(128) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `slug`, `text`) VALUES
(4, 'php ogreniyorum', 'php-ogreniyorum', 'beyler php ogreniyorum ve ilk makale kayıt islemlerimiz basladi.'),
(5, 'asp.net ogreniyorum', 'aspnet-ogreniyorum', 'asp.net ogreniyorum ve xxx islemleri ole bi basladimki hala devam ediyorum.'),
(6, 'html ogreniyorum', 'html-ogreniyorum', 'htmle basladik ulan ne guzel gidiyor derken nerden bilecektim sanal hammal olacagimi oldukmu sanal hammal hayatim iste o zaman kaydi gitti.');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(11) NOT NULL,
  `name` varchar(140) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`) VALUES
(3, 'administrator'),
(4, 'customer'),
(5, 'vendor');

-- --------------------------------------------------------

--
-- Table structure for table `showcase`
--

CREATE TABLE `showcase` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text,
  `show_home_page` int(11) DEFAULT NULL,
  `themes_area_id` int(11) NOT NULL,
  `themes_id` int(11) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `showcase`
--

INSERT INTO `showcase` (`id`, `title`, `content`, `show_home_page`, `themes_area_id`, `themes_id`, `create_time`, `update_time`) VALUES
(2, 'vitrin1 gun', '<p>vitrin denemesi başlangı&ccedil;tır. gun&nbsp;</p>\r\n', 1, 4, 0, '2015-12-15 20:42:39', '2016-02-01 20:04:05'),
(3, 'vitrin2 başlık', '<p>vitrin2 i&ccedil;erik deneme yazısı&nbsp;kısmıdır.</p>\r\n', 1, 4, 24, '2016-02-01 07:58:51', '2016-02-01 12:00:19'),
(4, 'vitrin3 başlık', '<p>vitrin3 i&ccedil;erik deneme yazısı kısmıdır.</p>\r\n', 1, 4, 23, '2016-02-01 08:27:38', '2016-02-01 11:48:04');

-- --------------------------------------------------------

--
-- Table structure for table `showcase_to_blog`
--

CREATE TABLE `showcase_to_blog` (
  `id` int(11) NOT NULL,
  `showcase_id` int(11) NOT NULL,
  `blog_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `showcase_to_categories`
--

CREATE TABLE `showcase_to_categories` (
  `id` int(11) NOT NULL,
  `showcase_id` int(11) NOT NULL,
  `categories_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `showcase_to_categories`
--

INSERT INTO `showcase_to_categories` (`id`, `showcase_id`, `categories_id`) VALUES
(73, 2, 2),
(74, 2, 6);

-- --------------------------------------------------------

--
-- Table structure for table `sidebar`
--

CREATE TABLE `sidebar` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `status` int(11) NOT NULL,
  `which_side` varchar(20) NOT NULL,
  `queue` int(11) DEFAULT NULL,
  `themes_id` int(11) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sidebar`
--

INSERT INTO `sidebar` (`id`, `title`, `content`, `status`, `which_side`, `queue`, `themes_id`, `create_time`, `update_time`) VALUES
(1, 'Sol Reklams', '<p><img src="assets/uploads/img/solreklam.png" /></p>\r\n', 1, 'left', 1, 31, '2015-12-30 20:08:07', '2016-01-21 13:23:52'),
(2, 'Sol Reklam 2s', '<p>Sool Rekalam 2 içerik kısmıdır.</p>\r\n', 1, 'left', 2, 30, '2015-12-30 20:17:06', '2016-01-20 09:30:12'),
(4, 'Sağ Reklam', '<p>sağ reklam 1 içerik kısmıdır.</p>\r\n', 0, 'right', 1, 30, '2015-12-30 20:19:40', '2016-01-20 08:47:59'),
(5, 'Sağ Reklam 2', '<p>sağ reklam 2 içerik ksımıdır</p>\r\n', 1, 'right', 2, 30, '2015-12-30 20:20:12', '2016-01-20 08:47:22'),
(6, 'Sol Reklam 3s', '<p>sol reklam içeriği</p>\r\n', 0, 'left', 3, 31, '2016-01-03 17:51:35', '2016-01-20 08:47:04'),
(7, '2 yeni', '<p>sdsadsds</p>\r\n', 1, 'right', 0, 30, '2016-01-20 07:25:37', '2016-01-20 08:28:17');

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

CREATE TABLE `site_settings` (
  `id` int(11) NOT NULL,
  `settings_name` varchar(120) NOT NULL,
  `settings_key` text NOT NULL,
  `settings_value` text NOT NULL,
  `created_time` timestamp NULL DEFAULT NULL,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`id`, `settings_name`, `settings_key`, `settings_value`, `created_time`, `updated_time`) VALUES
(1, 'enable_responsive', 'enable_responsive', '', '2015-11-21 22:00:00', '2015-12-22 20:35:57'),
(2, 'restrict_roaming', 'restrict_roaming', 'enable', '2015-11-21 22:00:00', '2016-02-13 21:06:51'),
(3, 'site_logo', 'site_logo', 'assets/uploads/system/images/site_logo_G0PdXLLsmVYmY2-logo.jpg', '2015-11-21 22:00:00', '2016-02-13 21:06:51'),
(4, 'watermark', 'watermark', '', '2015-11-21 22:00:00', '2016-02-13 21:06:51'),
(5, 'home_page_sidebar', 'home_page_sidebar', 'sidebar', '2015-11-21 22:00:00', '2016-02-13 21:06:51'),
(6, 'home_page_passive_footer', 'home_page_passive_footer', '', '2015-11-21 22:00:00', '2016-01-14 07:47:13'),
(7, 'category_page_sidebar', 'category_page_sidebar', 'leftbar', '2015-11-21 22:00:00', '2016-02-13 21:06:51'),
(8, 'category_page_passive_footer', 'category_page_passive_footer', '', '2015-11-21 22:00:00', '2015-11-22 18:40:15'),
(9, 'search_page_sidebar', 'search_page_sidebar', 'leftbar', '2015-11-21 22:00:00', '2016-02-13 21:06:51'),
(10, 'search_page_passive_footer', 'search_page_passive_footer', '', '2015-11-21 22:00:00', '2015-11-22 18:40:35'),
(11, 'brand_page_sidebar', 'brand_page_sidebar', 'leftbar', '2015-11-21 22:00:00', '2016-02-13 21:06:51'),
(12, 'brand_page_passive_footer', 'brand_page_passive_footer', '', '2015-11-21 22:00:00', '2015-11-22 18:40:46'),
(13, 'product_page_sidebar', 'product_page_sidebar', 'passive', '2015-11-21 22:00:00', '2016-02-13 21:06:51'),
(14, 'product_page_passive_footer', 'product_page_passive_footer', '', '2015-11-21 22:00:00', '2015-11-22 18:40:56'),
(15, 'blog_page_sidebar', 'blog_page_sidebar', 'rightbar', '2015-11-21 22:00:00', '2016-02-13 21:06:51'),
(16, 'blog_page_passive_footer', 'blog_page_passive_footer', 'passive_footer', '2015-11-21 22:00:00', '2016-02-13 21:06:51'),
(17, 'home_restrict_roaming', 'home_restrict_roaming', '', '2015-11-25 22:00:00', '2016-02-13 21:06:51'),
(18, 'listing_restrict_roaming', 'listing_restrict_roaming', 'enable', '2015-11-25 22:00:00', '2016-02-13 21:06:51'),
(19, 'details_restrict_roaming', 'details_restrict_roaming', 'enable', '2015-11-25 22:00:00', '2016-02-13 21:06:51'),
(20, 'blog_restrict_roaming', 'blog_restrict_roaming', 'enable', '2015-11-25 22:00:00', '2016-02-13 21:06:51');

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `id` int(11) NOT NULL,
  `themes_area_id` int(11) NOT NULL,
  `default_themes_id` tinyint(1) NOT NULL,
  `active_themes_id` tinyint(1) NOT NULL,
  `name` varchar(120) NOT NULL,
  `content` text NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `themes_area_id`, `default_themes_id`, `active_themes_id`, `name`, `content`, `file_path`, `create_time`, `update_time`) VALUES
(17, 2, 1, 1, 'hazir tema footer', '</section>\r\n</div>\r\n<div id="footer">\r\n<div class="container">\r\nhazir tema footer icerik\r\n<br>\r\ngüncelleme: ev footer alanı\r\n</div>\r\n</div>', 'themes/footer/footer17.php', '2015-10-04 14:38:48', '2015-12-06 20:48:40'),
(22, 1, 0, 1, 'maviweb1', '<div id="header">\r\n<div class="container">\r\n<div class="logo" style="width:120px;">{logo}</div>\r\n<div class="hmenu">\r\n{kategoriler}\r\n</div>\r\n<div class="vendor_load">{kullanıcı adı}</div>\r\n</div>\r\n</div>\r\n<section>\r\n<div class="container">', 'themes/header/header22.php', '2015-10-06 20:28:52', '2016-02-13 23:38:55'),
(23, 4, 1, 0, 'vitrin teması -varsayılan - blogsuz', '<div class="col-lg-12 row">\r\n<div class="vitrin_alan">\r\n<div class="vitrin_baslik">{vitrin başlık}</div>\r\n<div class="vitrin_icerik">{vitrin içerik}</div>\r\n</div>\r\n</div>', 'themes/showcase/frame/showcase-frame23.php', '2015-10-06 20:33:22', '2016-02-05 22:13:22'),
(24, 4, 0, 1, 'vitrin teması -aktif - bloglu', '<div class="col-lg-12 row">\r\n<div class="vitrin_alan">\r\n<div class="vitrin_baslik">{vitrin başlık}</div>\r\n<div class="vitrin_icerik">{vitrin içerik}</div>\r\n<div class="vitrin_blog_alan">{blog listele}</div>\r\n</div>\r\n</div>', 'themes/showcase/frame/showcase-frame24.php', '2015-10-06 20:35:27', '2016-02-05 22:13:09'),
(25, 1, 0, 0, 'tema yapiliyor', '<div id="header"> \r\n  <div class="logo">{logo}</div>\r\n  <div class="hmenu">\r\n   <ul class="hmenu_ul">\r\n    {kategoriler}\r\n   </ul>\r\n  </div>\r\n  </div>', 'themes/header/header25.php', '2015-10-12 17:11:32', '2015-12-03 21:53:12'),
(26, 1, 1, 0, 'yeni header', 'asd qwe qweasd', 'themes/header/header26.php', '2015-12-21 18:57:49', '2015-12-22 21:32:54'),
(27, 8, 0, 1, 'blog views', '<div class="blog_list">\n<div class="blog_image">{sayfa resim}</div>\n<div class="blog_title">{sayfa başlık}</div>\n<div class="blog_content">{sayfa içerik}</div>\n</div>', 'themes/blog/views/blog-views27.php', '2015-12-21 18:59:04', '2016-01-28 18:09:02'),
(29, 8, 1, 0, 'maviweb1', '<div class="blog_list">\r\n<div class="blog_baslik">{sayfa başlık}</div>\r\n<div class="blog_icerik">{sayfa içerik}</div>\r\n</div>', 'themes/blog/views/blog-views29.php', '2015-12-22 19:08:56', '2016-01-28 19:35:16'),
(30, 10, 1, 1, 'yeni bileşen tema', '<div class="blok_alan">\n<div class="blok_ust"><h3>{bileşen başlık}</h3></div>\n<div class="blok_orta">{bileşen içerik}</div>\n<div class="blok_alt"></div>\n</div>', 'themes/sidebar/frame/sidebar-frame30.php', '2016-01-18 07:19:13', '2016-01-28 18:09:07'),
(31, 10, 0, 0, 'qwe', 'qwe<br>{bileşen içerik}', 'themes/sidebar/frame/sidebar-frame31.php', '2016-01-18 07:19:48', '2016-01-20 11:13:05'),
(32, 11, 1, 1, 'anasayfa', '{slider}{banner}{vitrin}', 'themes/home/home32.php', '2016-02-05 17:14:22', '2016-02-05 21:23:35'),
(33, 14, 1, 1, 'slider', '<div class="col-lg-8">\r\n<div class="row">\r\n<div class="site-swiper-slider swiper-container">\r\n<div class="swiper-wrapper">\r\n{slider}\r\n<div class="swiper-slide"><a href="{slider link}" title="{slider alt_text}"><img src="{slider resim}" alt="{slider alt_text}" /></a></div>\r\n{/slider}\r\n</div>\r\n<!-- Add Pagination -->\r\n<div class="swiper-pagination sp-slider"></div>\r\n</div>\r\n</div>\r\n</div>', 'themes/slider/slider33.php', '2016-02-05 20:13:17', '2016-02-05 22:24:59'),
(34, 15, 1, 1, 'banner', '<div class="col-lg-4">\r\n<div class="site-swiper-banner swiper-container">\r\n	<div class="swiper-wrapper">\r\n	{banner}\r\n		<div class="swiper-slide"><a href="{banner link}" title="{banner alt_text}"><img src="{banner resim}" alt="{banner alt_text}" /></a></div>\r\n	{/banner}\r\n	</div>\r\n<!-- Add Pagination -->\r\n<div class="swiper-pagination sp-banner"></div>\r\n</div>\r\n</div>', 'themes/banner/banner34.php', '2016-02-05 20:22:30', '2016-02-05 22:33:15'),
(35, 17, 1, 1, 'üye girişi', '<?php echo form_open(''auth/login''); ?>\r\n	<table>\r\n		<tr>\r\n			<td>kullanıcı adı:</td>\r\n			<td><?php echo form_input(''username'',(isset($username))?$username:'''',''placeholder="Kullanıcı adınız" class="form-control"''); ?></td>\r\n		</tr>\r\n		<tr>\r\n			<td>şifre:</td>\r\n			<td><?php echo form_password(''password'','''',''placeholder="Şifreniz" class="password form-control"''); ?></td>\r\n		</tr>\r\n		<tr>\r\n			<td> </td>\r\n			<td><?php echo form_submit(''submit'',''Giriş Yap'',''class="btn btn-lg btn-success btn-block"''); ?></td>\r\n		</tr>\r\n		<tr>\r\n			<td></td>\r\n			<td>\r\n				<?php \r\n					echo validation_errors(''<p style="color:#dc0001;">'');\r\n					echo (isset($errors))? ''<p style="color:#dc0001;">''.$errors.''</p>'' : '''' ;\r\n				?>\r\n			</td>\r\n		</tr>\r\n	</table>\r\n<?php echo form_close(); ?>', 'themes/auth/login/login35.php', '2016-02-09 20:41:17', '2016-02-13 23:47:10');

-- --------------------------------------------------------

--
-- Table structure for table `themes_area`
--

CREATE TABLE `themes_area` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `file_extension` varchar(120) NOT NULL,
  `class_name` varchar(80) NOT NULL,
  `limited` int(11) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT NULL,
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `themes_area`
--

INSERT INTO `themes_area` (`id`, `parent_id`, `name`, `file_path`, `file_extension`, `class_name`, `limited`, `create_time`, `update_time`) VALUES
(1, 0, 'header', 'themes/header/', 'header', 'header', NULL, '2015-09-22 21:00:00', '2015-10-08 19:41:35'),
(2, 0, 'footer', 'themes/footer/', 'footer', 'footer', NULL, '2015-09-22 21:00:00', '2015-10-08 19:41:39'),
(3, 0, 'showcase', 'themes/showcase/', 'showcase', 'showcase', NULL, '2015-09-22 21:00:00', '2015-10-08 19:41:47'),
(4, 3, 'showcase frame', 'themes/showcase/frame/', 'showcase-frame', 'showcase_frame', NULL, '2015-09-22 21:00:00', '2015-10-08 19:42:15'),
(6, 0, 'blog', 'themes/blog/', 'blog', 'blog', NULL, '2015-09-22 21:00:00', '2015-10-08 19:42:18'),
(8, 6, 'blog views', 'themes/blog/views/', 'blog-views', 'blog_views', NULL, '2015-09-22 21:00:00', '2015-10-08 19:42:29'),
(9, 0, 'sidebar', 'themes/sidebar/', 'sidebar', 'sidebar', NULL, '2016-01-17 22:00:00', '2016-01-18 08:18:20'),
(10, 9, 'sidebar frame', 'themes/sidebar/frame/', 'sidebar-frame', 'sidebar_frame', NULL, '2016-01-17 22:00:00', '2016-01-18 08:18:20'),
(11, 0, 'home', 'themes/home/', 'home', 'home', 1, '2016-02-01 22:00:00', '2016-02-05 19:55:11'),
(14, 0, 'slider', 'themes/slider/', 'slider', 'slider', 1, '2016-02-04 22:00:00', '2016-02-05 19:55:03'),
(15, 0, 'banner', 'themes/banner/', 'banner', 'banner', 1, '2016-02-04 22:00:00', '2016-02-05 19:55:03'),
(16, 0, 'auth', 'themes/auth/', 'auth', 'auth', NULL, '2016-02-08 22:00:00', '2016-02-09 21:43:27'),
(17, 16, 'login', 'themes/auth/login/', 'login', 'login', NULL, '2016-02-08 22:00:00', '2016-02-09 21:43:31'),
(18, 16, 'register', 'themes/auth/register/', 'register', 'register', NULL, '2016-02-08 22:00:00', '2016-02-09 21:43:34');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(120) NOT NULL,
  `name` varchar(120) NOT NULL,
  `surname` varchar(120) NOT NULL,
  `created_time` datetime DEFAULT NULL,
  `updated_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `name`, `surname`, `created_time`, `updated_time`) VALUES
(2, 'huseyindol', '4af6e55debe20f1aed19dcd8905312873dee6d06d33f973e2b958e43f476c0f1d709233a1eefef25f6382c1cda05a719d927171653f95bbef3409ae524dd7045K853qiCk53FP+wifJ+zlZZhw+jUBUP1lgXhML4WO9BY=', 'huseyindol@gmail.coms', 'huseyin', 'dol', '2015-09-09 00:00:00', '2015-10-06 22:41:04'),
(3, 'zehradol', 'bd8128748da0b91bf001d2601b2bec2b8744dab670884fc10af1782f88a7cc02d1fac9ff6f2d7029adbcc19b0ffd591e04a8a2e82b3c14cdb9fba9c26d1c70ceR7ND6JMqOJfc5lnz6jQ176QOP+begsUv8JzMgwf07mM=', 'zehradol@hotmail.com', 'zehra', 'dol', '2015-09-15 00:00:00', '2015-09-15 20:15:16'),
(4, 'yunusdol', 'ff4104efc909d83477c4fd709621852446aafe88534dd027fb37fc0814aef32dded28aae6c6e18963f4e30dff750b9e6bacdbc3c2b0a44d49593275f2f8617a4N0eawTrIDz6Q6jsAEijGp0A98vHasOXXerMjKihkXuE=', 'yunusdol@hotmail.com', 'yunus', 'dol', '0000-00-00 00:00:00', '2015-09-15 20:33:56'),
(5, 'nergizdol', 'bd7437119079aae2b5fc1dac618a6a74483e06a8d10b0457722bee6aacbe615b79d2d8565d1e0acdc3e93934ed1a33e6341994b01c9a0e674cd3075d6ac331b4y9aqbiTdYX1uNXq4CS9a8BlQ5NOvt71C0cEkmovfcu8=', 'nergizdol@gmail.com', 'nergiz', 'dol', '2015-09-15 22:40:33', '2015-09-15 20:40:33');

-- --------------------------------------------------------

--
-- Table structure for table `users_details`
--

CREATE TABLE `users_details` (
  `users_id` int(11) NOT NULL,
  `phone` char(15) NOT NULL,
  `phone2` char(15) NOT NULL,
  `gsm` char(15) NOT NULL,
  `seniority` varchar(80) NOT NULL,
  `tc_no` char(11) NOT NULL,
  `corporation` varchar(255) NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_details`
--

INSERT INTO `users_details` (`users_id`, `phone`, `phone2`, `gsm`, `seniority`, `tc_no`, `corporation`, `address`) VALUES
(2, '2125983352', '1234567890', '5445582825', 'senior front-end developers', '1234567890', 'projesoft bilişim hizmetleri web tasarım ve programlama', 'fevzi çakmak mahallesi türkeli sokak no:30 d:4'),
(3, '0123456789', '0123456789', '0123456789', 'muhasebe', '01234567891', 'yılmazer a.ş', 'zehra - xxx xxxx xxxxx xxx'),
(4, '0123456789', '0123456789', '0123456789', 'satış', '01234567891', 'yunus - xxx xxxx xxxxx xxx', 'yunus - xxx xxxx xxxxx xxx'),
(5, '0123456789', '0123456789', '0123456789', 'vezneci', '0123456789', 'nergiz - xxx xxxx xxxxx xxx', 'nergiz - xxx xxxx xxxxx xxx');

-- --------------------------------------------------------

--
-- Table structure for table `users_permissions`
--

CREATE TABLE `users_permissions` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `permissions_id` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users_permissions`
--

INSERT INTO `users_permissions` (`id`, `users_id`, `permissions_id`) VALUES
(3, 2, 3),
(4, 2, 4),
(5, 2, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pages_type` (`pages_type`) USING BTREE;

--
-- Indexes for table `blog_to_showcase`
--
ALTER TABLE `blog_to_showcase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ci_sessions`
--
ALTER TABLE `ci_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ci_sessions_timestamp` (`timestamp`);

--
-- Indexes for table `custom_code`
--
ALTER TABLE `custom_code`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slug` (`slug`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `showcase`
--
ALTER TABLE `showcase`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `showcase_to_blog`
--
ALTER TABLE `showcase_to_blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `showcase_to_categories`
--
ALTER TABLE `showcase_to_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sidebar`
--
ALTER TABLE `sidebar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `themes_area_id` (`themes_area_id`);

--
-- Indexes for table `themes_area`
--
ALTER TABLE `themes_area`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `users_details`
--
ALTER TABLE `users_details`
  ADD UNIQUE KEY `users_id` (`users_id`);

--
-- Indexes for table `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`),
  ADD KEY `permissions_id` (`permissions_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `blog_to_showcase`
--
ALTER TABLE `blog_to_showcase`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `custom_code`
--
ALTER TABLE `custom_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `showcase`
--
ALTER TABLE `showcase`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `showcase_to_blog`
--
ALTER TABLE `showcase_to_blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `showcase_to_categories`
--
ALTER TABLE `showcase_to_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT for table `sidebar`
--
ALTER TABLE `sidebar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `themes_area`
--
ALTER TABLE `themes_area`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users_permissions`
--
ALTER TABLE `users_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `themes`
--
ALTER TABLE `themes`
  ADD CONSTRAINT `themes-area` FOREIGN KEY (`themes_area_id`) REFERENCES `themes_area` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users_details`
--
ALTER TABLE `users_details`
  ADD CONSTRAINT `details-users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users_permissions`
--
ALTER TABLE `users_permissions`
  ADD CONSTRAINT `us_pe-to-permissions` FOREIGN KEY (`permissions_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `us_pe-to-users` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

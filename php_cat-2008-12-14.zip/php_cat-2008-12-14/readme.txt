
HOW TO INSTALL
1- import SQL.sql file.
2- look at example.php and example_admin.php files in /examples directory using your browser.

For extra settings look at config.inc.php!
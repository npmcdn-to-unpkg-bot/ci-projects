<?php
highlight_file("highlights/add.php");
?>
<?php
highlight_file("highlights/del.php");
?>
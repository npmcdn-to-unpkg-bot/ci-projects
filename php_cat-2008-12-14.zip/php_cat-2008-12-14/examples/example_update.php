<?php
highlight_file("highlights/update.php");
?>


CREATE DATABASE IF NOT EXISTS `nested_model`;
USE `nested_model`;

CREATE TABLE IF NOT EXISTS `category` (
  `cat_id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL,
  `cat_name` varchar(200) character set utf8 NOT NULL,
  `dsc` text character set utf8 NOT NULL,
  `cat_link` varchar(200) character set utf8 NOT NULL,
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=174;


INSERT INTO `category` (`cat_id`, `parent_id`, `cat_name`, `dsc`, `cat_link`, `lft`, `rgt`) VALUES
(173, 165, 'Plasma', '', 'plasma', 5, 6),
(165, 164, 'Televisions', '', 'televisions', 2, 9),
(166, 164, 'Portable Electronics', '', 'portable-electronics', 10, 19),
(172, 165, 'Lcd', '', 'lcd', 7, 8),
(171, 165, 'Tube', '', 'tube', 3, 4),
(170, 167, 'Flash', '', 'flash', 12, 13),
(168, 166, 'Cd Players', '', 'cd-players', 17, 18),
(169, 166, '2 Way Radios', '', '2-way-radios', 15, 16),
(167, 166, 'Mp3 Players', '', 'mp3-players', 11, 14),
(164, 0, 'Electronics', '', 'electronics', 1, 20);